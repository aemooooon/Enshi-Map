package cn.gublog.test05;

import cn.gublog.test05.mapper.UserMapper;
import cn.gublog.test05.mapper.UserMapper2;
import cn.gublog.test05.model.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class Test05ApplicationTests {
    @Autowired
    UserMapper2 userMapper2;

    @Test
    void contextLoads() {
        List<User> allUser = userMapper2.getAllUsers();
        System.out.println(allUser);

    }

}
