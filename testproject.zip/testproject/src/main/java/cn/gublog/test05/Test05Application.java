package cn.gublog.test05;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan(basePackages = "cn.gublog.test05.mapper")
public class Test05Application {

    public static void main(String[] args) {
        SpringApplication.run(Test05Application.class, args);
    }

}
