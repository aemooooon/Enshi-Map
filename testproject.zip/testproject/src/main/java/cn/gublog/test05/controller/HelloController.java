package cn.gublog.test05.controller;

import cn.gublog.test05.mapper.UserMapper2;
import cn.gublog.test05.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class HelloController {

    @Autowired
    UserMapper2 userMapper2;

    @GetMapping("/helloworld")
    public List<User> helloWorldHandler () {

        List<User> allUser = userMapper2.getAllUsers();
        return allUser;

    }

}
